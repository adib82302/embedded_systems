/*
 *
 * CSEE 4840 Lab 2 
 * Name/UNI: Kristian Nikolov (kdn2117)
 * Name/UNI: Adib Khondoker (aak2250)
 */

//libraries
#include "fbputchar.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include "usbkeyboard.h"
#include "lookup_table.h"
#include <pthread.h>
#include <time.h>
#include <unistd.h>

//left and right arrow keycodes
#define LEFT_ARROW 0x50  // Example keycode for Left Arrow
#define RIGHT_ARROW 0x4F  // Example keycode for Right Arrowf

//repeat delay
#define REPEAT_DELAY 300000 // Initial delay (300ms) before repeating
#define REPEAT_RATE 50000   // Repeat rate (50ms) for continued input

//network definition
#define SERVER_HOST "128.59.19.114"
#define SERVER_PORT 42000

//buffer definitions
#define BUFFER_SIZE 441
#define TOP 0
#define BOTTOM 23
#define DIVIDE 15
#define OUT 16
#define IN 8
#define WIDTH 63

// variables for handling multiple key inputs
uint8_t held_keycode = 0;
char held_ascii = 0;
struct timespec last_repeat_time;
uint8_t prev_keycodes [2] = {0x00, 0x00};
char ascii_char = 0;

// buffer for key input
char keypress_buffer[BUFFER_SIZE][12]; // Stores up to 128 keypresses as binary strings
int keypress_count = 0;
int cursor_position = 0;

/* Socket file descriptor */
int sockfd; 
struct libusb_device_handle *keyboard;
uint8_t endpoint_address;

//network variables
pthread_t network_thread;
void *network_thread_f(void *);

// function calls for compiler
void setup_screen();
void handle_keypress(const char *keystate, char ascii_char, uint8_t modifiers);
void update_input_display();
void display_message(const char *message);
void clear_receive_area();

//network function
void *network_thread_f(void *ignored) {
    char recvBuf[BUFFER_SIZE];
    int n;
    /* Receive data */
    while ((n = read(sockfd, &recvBuf, BUFFER_SIZE - 1)) > 0) {
        recvBuf[n] = '\0';
        printf("%s", recvBuf);
        display_message(recvBuf);
    }
    return NULL;
}

/* Initialize the screen */
void setup_screen() {
    fbclear();
    for (int col = 0; col < WIDTH; col++) {
        fbputchar('*', TOP, col);
        fbputchar('-', DIVIDE, col);
        fbputchar('*', BOTTOM, col);
    }
    fbputs(">", OUT, 0);
    
    // Properly initialize the input buffer with spaces
    memset(keypress_buffer, ' ', sizeof(keypress_buffer));
    keypress_count = 0;
    cursor_position = 1;

    update_input_display(); // Ensure the cursor is displayed from the start
}

/* Update the input display with a static cursor */
void update_input_display() {
    // Clear the entire input area
    cursor_clear();
    fbputs(">", OUT, 0);

    int row = 16; // Starting row
    int col = 1;  // Starting column after '>'

    // Draw all characters in the buffer
    for (int i = 0; i < keypress_count; i++) {
        fbputchar(keypress_buffer[i][0], row, col++);
        if (col >= WIDTH) { // Handle line wrapping
            col = 0;
            row++;
            if (row > 22) break;
        }
    }

    // Draw the cursor explicitly
    if (cursor_position > keypress_count) {
        // Cursor is at the end of the input
        fbputchar('|', row, col);
    } else {
        // Cursor is within the input
        int cursor_col = (cursor_position % WIDTH);
        int cursor_row = row + (cursor_position / WIDTH);
        if (cursor_row <= 22) {
            fbputchar('|', cursor_row, cursor_col);
        }
    }

    // Display character count on the top line
    int count = keypress_count;

    // Clear previous character count
    for (int col = 50; col < WIDTH; col++) {
        fbputchar(' ', 14, col);
    }

    // Draw the character count
    fbputchar((count / 100) % 10 + '0', 14, 57); 
    fbputchar((count / 10) % 10 + '0', 14, 58);  
    fbputchar((count % 10) + '0', 14, 59);       
    fbputchar('/', 14, 60); 
    fbputchar('4', 14, 61);
    fbputchar('4', 14, 62);
    fbputchar('1', 14, 63);
}



/* Handle input, store in buffer, update display */
void handle_keypress(const char *keystate, char ascii_char, uint8_t modifiers) {
    uint8_t keycode = (uint8_t)strtol(keystate + 14, NULL, 16);
    uint8_t extra_keycode = (uint8_t)strtol(keystate + 22, NULL, 16);

// Reset held key if no extra key is pressed
    if (extra_keycode == 0) {
        held_keycode = 0;
        held_ascii = 0;
    }

    if (ascii_char == '\n') { // Enter key
        char message_to_send[BUFFER_SIZE] = {0};
        int msg_length = 0;

        for (int i = 0; i < keypress_count; i++) {
            message_to_send[msg_length++] = keypress_buffer[i][0];
        }

        if (msg_length > 0) {
            message_to_send[msg_length++] = '\n';
            send(sockfd, message_to_send, msg_length, 0);
        }

        memset(keypress_buffer, ' ', sizeof(keypress_buffer)); // Clear buffer with spaces
        keypress_count = 0;
        cursor_position = 1;
        cursor_clear();
        fbputs(">", OUT, 0);
        fbputchar('|', OUT, cursor_position);
        held_keycode = 0; // Stop any held key action
        held_ascii = 0;
    } 
    else if (ascii_char == '\b') { // Backspace
        if (cursor_position > 1) {
            // Shift characters to the left of the cursor position
            for (int i = cursor_position - 1; i < keypress_count - 1; i++) {
                keypress_buffer[i][0] = keypress_buffer[i + 1][0];
            }
            keypress_count--;
            keypress_buffer[keypress_count][0] = ' '; // Clear the last character space
            cursor_position--;
            update_input_display();
        }
        held_keycode = 0; // Stop repeat on backspace
    } 
    else if (ascii_char == LEFT_ARROW && !modifiers) { // Left Arrow
        if (cursor_position > 1) { 
            cursor_position--;
        }
        update_input_display();
        held_keycode = 0; // Stop repeat on arrow key
    } 
    else if (ascii_char == RIGHT_ARROW && !modifiers) { // Right Arrow
        if (cursor_position <= keypress_count && cursor_position < BUFFER_SIZE - 1) {
            cursor_position++;
        }
        update_input_display();
        held_keycode = 0; // Stop repeat on arrow key
    } 
    else if (ascii_char != 0 && keypress_count < BUFFER_SIZE - 1) {
        // Add character to buffer at the current cursor position
        for (int i = keypress_count; i > cursor_position - 1; i--) {
            keypress_buffer[i][0] = keypress_buffer[i - 1][0];
        }
        keypress_buffer[cursor_position - 1][0] = ascii_char;
        keypress_buffer[cursor_position][1] = '\0';
        keypress_count++;
        cursor_position++;
        update_input_display();
    }

    // Handle key release
    if (keycode == 0) {
        held_keycode = 0;
        held_ascii = 0;
    }

}

/* Display a message in the top section of the screen */
void display_message(const char *message) {
    static int row = 1;
    int col = 0;
    const char *p = message;

    while (*p) {
        if (*p == '\n' || col >= WIDTH) {
            row++;
            col = 0;
        }
        if (row >= DIVIDE) {
            row = 1;
            clear_receive_area();
        }
        if (*p != '\n') {
            fbputchar(*p, row, col++);
        }
        p++;
    }
    row++;
}

/* Clear only the receive area */
void clear_receive_area() {
    for (int row = 1; row < DIVIDE; row++) {
        for (int col = 0; col < WIDTH; col++) {
            fbputchar(' ', row, col);
        }
    }
}



int main() {
    int err;
    struct sockaddr_in serv_addr;
    struct usb_keyboard_packet packet;
    int transferred;
    char keystate[12];

    if ((err = fbopen()) != 0) {
        fprintf(stderr, "Error: Could not open framebuffer: %d\n", err);
        exit(1);
    }

    setup_screen();

    /* Open the keyboard */
    if ((keyboard = openkeyboard(&endpoint_address)) == NULL) {
        fprintf(stderr, "Did not find a keyboard\n");
        exit(1);
    }

    /* Create a TCP communications socket */
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        fprintf(stderr, "Error: Could not create socket\n");
        exit(1);
    }

    /* Get the server address */
    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(SERVER_PORT);
    if (inet_pton(AF_INET, SERVER_HOST, &serv_addr.sin_addr) <= 0) {
        fprintf(stderr, "Error: Could not convert host IP \"%s\"\n", SERVER_HOST);
        exit(1);
    }

    /* Connect the socket to the server */
    if (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        fprintf(stderr, "Error: connect() failed. Is the server running?\n");
        exit(1);
    }

    /* Start the network thread */
    pthread_create(&network_thread, NULL, network_thread_f, NULL);

    uint8_t curr_keycode = 0x00;
    /* Look for and handle keypresses */
    for (;;) {
        libusb_interrupt_transfer(keyboard, endpoint_address,
                                  (unsigned char *)&packet, sizeof(packet),
                                  &transferred, 0);
        if (transferred == sizeof(packet)) {
            // Prepare the keycode string with raw binary output
            int print = 0;
            if (packet.keycode[0] != prev_keycodes[0]) {
                curr_keycode = packet.keycode[0];
            }
            else if (packet.keycode[1] != prev_keycodes[1]) {
                curr_keycode = packet.keycode[1];
            }
            else {
                curr_keycode = 0;
            }
            if (prev_keycodes[0] != 0 && prev_keycodes[1] != 0 && (packet.keycode[0] == 0 || packet.keycode[1] == 0)) {
                curr_keycode = 0;
            }
            if (curr_keycode != 0) {
                print = 1;
            }
            prev_keycodes[0] = packet.keycode[0];
            prev_keycodes[1] = packet.keycode[1];
            sprintf(keystate, "MOD:%02x | KEYCODE:%02x | EXTRA:%02x", packet.modifiers, curr_keycode);

            
            // Display in the terminal for debugging
            printf("%s\n", keystate);
            printf("%d\n", packet.keycode[0]);
            printf("%d\n", packet.keycode[1]);

            // Convert keycode to ASCII
            ascii_char = keycode_to_char(packet.modifiers, curr_keycode);
            
            // Process the keypress and update display
            if (print) {
                handle_keypress(keystate, ascii_char, packet.modifiers);
            }

            if (curr_keycode == 0x29) { /* ESC pressed? */
                break;
            }
        }
    }

    /* Terminate the network thread */
    pthread_cancel(network_thread);
    pthread_join(network_thread, NULL);

    return 0;
}

